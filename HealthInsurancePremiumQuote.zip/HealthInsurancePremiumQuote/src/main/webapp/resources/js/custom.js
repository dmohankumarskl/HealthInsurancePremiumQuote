var app = angular.module("HealthIPQManage", []);
app.controller("healthIPQCtrl", function($scope, $http) {
	$scope.hipq = {
		id : -1,
		name : "",
		gender : "",
		age : "",
	};

	var selectedHabitlst = {

	};

	var selectedhealthlist = {

	};

	$scope.resetForm = function() {
		$scope.hipq = angular.copy($scope.hipq);
	};

	$scope.healthlist = [ {
		'name' : 'Hypertension'
	}, {
		'name' : 'Blood pressure'
	}, {
		'name' : 'Blood sugar'
	}, {
		'name' : 'Overweight'
	} ];

	$scope.habitlist = [ {
		'name' : 'Smoking:'
	}, {
		'name' : 'Alcohol'
	}, {
		'name' : 'Daily exercise'
	}, {
		'name' : 'Drugs'
	} ];

	$scope.submitHIPQ = function() {
		$http({
			method : "POST",
			url : getApplicationUrl() + 'submitHealthIPQ',
			data : angular.toJson($scope.hipq)
		}).then(function successCallback(response) {
			alert(response.data.response);
		}, function errorCallback(response) {
			alert(response.statusText);
		});
	};
})