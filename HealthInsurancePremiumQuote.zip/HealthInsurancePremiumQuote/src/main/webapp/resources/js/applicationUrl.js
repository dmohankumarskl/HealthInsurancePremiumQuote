/**
 * 
 */

function getApplicationUrl() {
	return "http://localhost:8080/HealthInsurancePremiumQuote/"
}