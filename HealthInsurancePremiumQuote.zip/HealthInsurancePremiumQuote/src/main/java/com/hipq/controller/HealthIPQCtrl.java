package com.hipq.controller;

import java.util.Collections;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hipq.pojo.HealthIPQuotePojo;
import com.hipq.service.HealthIPQService;

@RestController
public class HealthIPQCtrl {

	@Autowired
	private HttpServletRequest request;
	HealthIPQService hipqServ = new HealthIPQService();

	@RequestMapping(value = "/submitHealthIPQ", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, String> addCountry(@RequestBody HealthIPQuotePojo obj) {
		try {
			return Collections.singletonMap("response", hipqServ.calculateQuote(obj));
		} catch (Exception e) {
			return null;
		}
	}

}
