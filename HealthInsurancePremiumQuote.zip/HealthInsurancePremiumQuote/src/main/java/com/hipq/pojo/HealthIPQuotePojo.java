package com.hipq.pojo;

import java.io.Serializable;
import java.util.LinkedHashMap;

public class HealthIPQuotePojo implements Serializable {

	private static final long serialVersionUID = 1L;

	private int id;

	private String name;

	private String gender;

	private String currentHealth;

	private int age;

	private LinkedHashMap<String, Boolean> selectedHabitlst;

	private LinkedHashMap<String, Boolean> selectedhealthlist;

	public HealthIPQuotePojo() {
		// Empty Constructor
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCurrentHealth() {
		return currentHealth;
	}

	public void setCurrentHealth(String currentHealth) {
		this.currentHealth = currentHealth;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public LinkedHashMap<String, Boolean> getSelectedHabitlst() {
		if (selectedHabitlst == null) {
			selectedHabitlst = new LinkedHashMap<String, Boolean>();
		}
		return selectedHabitlst;
	}

	public void setSelectedHabitlst(LinkedHashMap<String, Boolean> selectedHabitlst) {
		this.selectedHabitlst = selectedHabitlst;
	}

	public LinkedHashMap<String, Boolean> getSelectedhealthlist() {
		if (selectedhealthlist == null) {
			selectedhealthlist = new LinkedHashMap<String, Boolean>();
		}
		return selectedhealthlist;
	}

	public void setSelectedhealthlist(LinkedHashMap<String, Boolean> selectedhealthlist) {
		this.selectedhealthlist = selectedhealthlist;
	}

}
