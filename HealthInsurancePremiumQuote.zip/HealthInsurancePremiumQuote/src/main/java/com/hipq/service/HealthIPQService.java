package com.hipq.service;

import java.text.NumberFormat;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map.Entry;

import com.hipq.pojo.HealthIPQuotePojo;

public class HealthIPQService {

	private double finalAmt;

	private double amt;

	private String healthMsg = "Health Insurance Premium for ";

	private String symbol = " : ";

	private String nullobjMsg = " Object returns null !!! ";

	private String wentwrong = "Something Went Wrong";

	private String invalidAge = "Please fill valid Age";

	public HealthIPQService() {
		super();
	}

	public String calculateQuote(HealthIPQuotePojo obj) {
		try {
			if (obj != null) {
				String msg = calculateQuoteSub(obj);
				obj = null;
				return msg;
			} else {
				return nullobjMsg;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return wentwrong;
		}
	}

	private String calculateQuoteSub(HealthIPQuotePojo obj) {
		finalAmt = 0.0;
		getpriceFormat();
		if (obj.getAge() > 0 && obj.getAge() < 18) {
			amt = getpriceFormat().get("18");
			return below18Age(obj);
		} else if (obj.getAge() >= 18 && obj.getAge() < 25) {
			amt = getpriceFormat().get("1825");
			return age1825(obj);
		} else if (obj.getAge() >= 25 && obj.getAge() < 30) {
			amt = getpriceFormat().get("2530");
			return age2530(obj);
		} else {
			return calculateQuoteSub2(obj);
		}
	}

	private String calculateQuoteSub2(HealthIPQuotePojo obj) {
		if (obj.getAge() >= 30 && obj.getAge() < 35) {
			amt = getpriceFormat().get("3035");
			return age3035(obj);
		} else if (obj.getAge() >= 35 && obj.getAge() < 40) {
			amt = getpriceFormat().get("3540");
			return age3540(obj);
		} else if (obj.getAge() >= 40) {
			amt = getpriceFormat().get("40");
			return ageabove40(obj);
		} else {
			return invalidAge;
		}
	}

	private String below18Age(HealthIPQuotePojo obj) {
		return commonQuoteBelow18(obj);
	}

	private String age1825(HealthIPQuotePojo obj) {
		return commonQuote(obj);
	}

	private String age2530(HealthIPQuotePojo obj) {
		return commonQuote(obj);
	}

	private String age3035(HealthIPQuotePojo obj) {
		return commonQuote(obj);
	}

	private String age3540(HealthIPQuotePojo obj) {
		return commonQuote(obj);
	}

	private String ageabove40(HealthIPQuotePojo obj) {
		return commonQuote(obj);
	}

	private String commonQuote(HealthIPQuotePojo obj) {
		finalAmt = finalAmt + amt;
		finalAmt = finalAmt + calculateHabits(obj) + calculateHealths(obj);
		finalAmt = finalAmt + addMalePer(obj);
		System.out.println(getFinalQute(obj));
		return getFinalQute(obj);
	}

	private String commonQuoteBelow18(HealthIPQuotePojo obj) {
		finalAmt = finalAmt + amt;
		finalAmt = finalAmt + calculateHabits(obj) + calculateHealths(obj);
		finalAmt = finalAmt + addMalePer(obj);
		return getFinalQute(obj);
	}

	private LinkedHashMap<String, Double> getpriceFormat() {
		LinkedHashMap<String, Double> map = new LinkedHashMap<String, Double>();
		amt = 5000;
		map.put("18", amt);
		double t1 = amt + amt * 10 / 100;
		double t2 = t1 + t1 * 10 / 100;
		double t3 = t2 + t2 * 10 / 100;
		double t4 = t3 + t3 * 10 / 100;
		double t5 = t4 + t4 * 10 / 100;
		map.put("1825", t1);
		map.put("2530", t2);
		map.put("3035", t3);
		map.put("3540", t4);
		map.put("40", t5);
		return map;
	}

	private double addMalePer(HealthIPQuotePojo obj) {
		if (obj.getGender().contains("male")) {
			return amt * 2 / 100;
		}
		return 0;
	}

	private double calculateHabits(HealthIPQuotePojo obj) {
		if (!obj.getSelectedHabitlst().isEmpty()) {
			double per = 0.0;
			double permin = 0.0;
			for (Entry<String, Boolean> h : obj.getSelectedHabitlst().entrySet()) {
				if (h.getKey().contains("Daily exercise") && h.getValue() != null && h.getValue()) {
					permin = amt * 3 / 100;
				} else if (h.getValue() != null && h.getValue()) {
					per = per + amt * 3 / 100;
				}
			}
			return per - permin;
		}
		return 0.0;
	}

	private double calculateHealths(HealthIPQuotePojo obj) {
		if (!obj.getSelectedhealthlist().isEmpty()) {
			double per = 0.0;
			for (Entry<String, Boolean> h : obj.getSelectedhealthlist().entrySet()) {
				if (h.getValue() != null && h.getValue()) {
					per = per + amt * 1 / 100;
				}
			}
			return per;
		}
		return 0.0;
	}

	private String getAmount(double amt) {
		try {
			NumberFormat formatter = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
			return formatter.format(amt);
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	private String getFinalQute(HealthIPQuotePojo obj) {
		return healthMsg + obj.getName() + symbol + "" + getAmount(finalAmt);
	}

	public double getFinalAmt() {
		return finalAmt;
	}

	public void setFinalAmt(double finalAmt) {
		this.finalAmt = finalAmt;
	}

	public double getAmt() {
		return amt;
	}

	public void setAmt(double amt) {
		this.amt = amt;
	}

}
